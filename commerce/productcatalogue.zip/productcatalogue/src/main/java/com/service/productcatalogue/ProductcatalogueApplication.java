package com.service.productcatalogue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProductcatalogueApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProductcatalogueApplication.class, args);
	}

}
