package com.service.productcatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProductcatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
