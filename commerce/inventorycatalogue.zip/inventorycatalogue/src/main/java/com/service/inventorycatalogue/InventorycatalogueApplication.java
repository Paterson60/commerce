package com.service.inventorycatalogue;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class InventorycatalogueApplication {

	public static void main(String[] args) {
		SpringApplication.run(InventorycatalogueApplication.class, args);
	}

}
