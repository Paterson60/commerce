package com.service.inventorycatalogue;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class InventorycatalogueApplicationTests {

	@Test
	void contextLoads() {
	}

}
